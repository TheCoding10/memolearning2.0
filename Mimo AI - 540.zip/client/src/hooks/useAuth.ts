// Re-export useAuth from AuthContext
export { useAuth } from '../context/AuthContext';
